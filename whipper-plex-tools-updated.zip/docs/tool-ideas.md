# Tool Ideas

This repo can grow into a small toolkit for Linux CD ripping and media-server music-library hygiene.

## High-value additions

### `whipper-drive-report`

Print a clean diagnostic report:

- Whipper version
- available CD devices
- configured read offset
- cache behavior
- current user groups
- whether `whipper`, `flac`, `metaflac`, `cdrdao`, and `eject` are installed

### `music-cover-repair`

Scan a music library and repair artwork:

- copy `.whipper/cover.jpg` or `.library-import/cover.jpg` to album-level `cover.jpg`
- embed artwork into FLACs that lack a PICTURE block
- skip files that already have artwork
- dry-run by default

### `music-flac-verify`

Run `flac -t` over a library and summarize failures.

### `whipper-rip-log-summary`

Parse `.whipper/*.log` files and summarize:

- rip date
- drive used
- read offset
- cache behavior
- AccurateRip status
- tracks with retries or failed verification

### `music-library-audit`

Report likely Plex, Jellyfin, or media-server library issues:

- missing album-level cover art
- missing embedded FLAC art
- missing MusicBrainz tags
- duplicate track numbers
- mixed album artists
- unpadded track numbers
- suspicious `Unknown Artist` / `Unknown Album` folders
